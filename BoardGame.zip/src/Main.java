import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Toolkit;

public class Main {
	
	JFrame frame = new JFrame("BearDiceGame");
	
	public Main() {
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(Main.class.getResource("/images/Fly.jpg")));
		frame.setBounds(200, 40, 1100, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// ùȭ��
		JPanel intro = new JPanel();
		intro.setBounds(200, 40, 1100, 750);
		intro.setLayout(null);
		
		// ���� ��� ��ư
		JButton btnNewButton = new JButton("���� ���");		
		btnNewButton.setFont(new Font("��ü�� ���� ��ü", Font.PLAIN, 23));
		btnNewButton.setBounds(826, 461, 150, 70);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Explanation();
				frame.setVisible(false);
			}
		});
		intro.add(btnNewButton);
		
		// ���� ���� ��ư
		JButton btnNewButton_1 = new JButton("���� ����");
		btnNewButton_1.setFont(new Font("��ü�� ���� ��ü", Font.PLAIN, 23));
		btnNewButton_1.setBounds(826, 551, 150, 75);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Option();
				frame.setVisible(false);
			}
		});
		intro.add(btnNewButton_1);
	
		
		// ����(���� �۾�)
		JLabel lblStatic = new JLabel("Static! \uD63C\uC790\uC11C\uB3C4 \uD558\uB294");
		lblStatic.setFont(new Font("�ü�ü", Font.PLAIN, 32));
		lblStatic.setBounds(103, 133, 342, 67);
		intro.add(lblStatic);
		
		// ����(ū �۾�)
		JLabel label = new JLabel("\uACF0 \uC8FC\uC0AC\uC704 \uAC8C\uC784");
		label.setFont(new Font("��ü�� ��ü �긲ü", Font.PLAIN, 56));
		label.setBounds(223, 151, 399, 171);
		intro.add(label);
				
		frame.getContentPane().add(intro);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Main.class.getResource("/images/background.png")));
		lblNewLabel.setBounds(0, 0, 1100, 750);
		intro.add(lblNewLabel);
		frame.setVisible(true);
				 		 
	}
	public static void main(String[] args) {
		new Main();
	}
}
